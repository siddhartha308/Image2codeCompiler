import logo from './logo.svg';
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import './App.css';
import Process from './components/Process';
import EditorC from './components/EditorC';

function App() {
  return (
    <div className="App">
    <EditorC></EditorC>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
  <path fill="rgb(63, 24, 70)" fill-opacity="1" d="M0,96L120,128C240,160,480,224,720,224C960,224,1200,160,1320,128L1440,96L1440,0L1320,0C1200,0,960,0,720,0C480,0,240,0,120,0L0,0Z"></path>
</svg>
     {/* <Navbar/>
     <Hero></Hero><br/>
     <br/>
     <br/>
     What do we do?
     <br/><br/><br/>
     <Process></Process>
     <br/><br/><br/> */}
    </div>
  );
}

export default App;
