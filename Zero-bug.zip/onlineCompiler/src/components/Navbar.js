import React from 'react'
import './styles.css'
export default function() {
  return (
    <div className='nav'>
        <h4>Logo</h4>
        <h4>link1</h4>
        <h4>link1</h4>
        <h4>link1</h4>

    </div>
  )
}
