import React from 'react'

export default function Hero() {
  return (
    <div className='hero'
    >
        <h1 style = {{"margin": "0","color":"white"}}>
            Dont You Want To Secure You Future?
        </h1>
    </div>
  )
}
