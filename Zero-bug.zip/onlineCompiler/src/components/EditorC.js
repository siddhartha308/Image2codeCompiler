import React ,{useState,useEffect}from 'react'
import axios from 'axios'
import "./editor.css"
import CodeEditor from '@uiw/react-textarea-code-editor';
import Select from "react-dropdown-select";
import "./styles.css"
import ResizePanel from "react-resize-panel";
// import Editor  from 'react-simple-code-editor';
// import { highlight, languages } from 'prismjs/components/prism-core';
// import 'prismjs/components/prism-clike';
// import 'prismjs/components/prism-python';
// import 'prismjs/themes/prism.css';
const lngArr = [
  {language : "python",
short : "py",
initcode: "#write your code"
},
{language : "cpp",
short : "cpp",
initcode: "#include<iostream> \nusing namespace std; \nint main(){\nreturn 0;\n}"
},
{language : "java",
short : "java",
initcode: "class Code {\npublic static void main(String[] args) {\nSystem.out.println(\"Hello, World!\"); \n  }\n}"
}

  
]
function EditorC() {
const [language,setLanguage]= useState(lngArr[0]);
const [bstatus,setBstatus] = useState(true);
  const [code, setCode] = useState(`#write your code`);
  const [input,setInput] = useState("");
  const [output,setOutput] = useState("");
  const [isWait,setIsWait] = useState(true);
  const [dropdownState, setDropdownState] = useState(false);
  const [dropdownValue, setDropdownValue] = useState("");
const [id,setId] = useState(Math.ceil(Math.random()*8000))
  const handleDropdownClick = () => {
    setDropdownState(!dropdownState);
  };
  const handleSetDropdownValue = (value) => {
    setDropdownValue(value);
    setDropdownState(!dropdownState);
  };
  const asyPromise=(cd,ip)=>{
  
return new Promise((resolve,reject)=>{
  setTimeout(()=>{reject(new Error("Call Took Much Time"))},1000000);
  var data = {
    code: cd,
    input: ip,
    language :language.short
  }
  // console.log(data)
  axios({
    method: "post",
    url: "/compile",
 
  data : data
  }).then(o=>{setBstatus(true);resolve(o.data.output);console.log(o.data.output)}).catch(e=>{reject(new Error("code has some errors"));setBstatus(true);});

})
}


const [intervalId, setIntervalId] = useState();

	
	

	const onStart= () => {

// setBstatus(false);
		if (!intervalId) {
      let uid  = Math.ceil(Math.random()*8000);
      var data = {
        code: code,
        input: input,
        language :language.short,
        id : uid,
      }
      axios({
        method: "post",
        url: "/asycompile",
        data : data
      }).then(o=>{console.log(o.data.output)}).catch(e=>{setBstatus(true);});

			let id = setInterval(()=>{
        
				      axios({
        method: "get",
        url: "/check/"+uid,
      }).then(e=>{
      //  clearInterval(id)
      // onStart();
      clearInterval(intervalId);
    //  setOutput(e.data.output);
    //  setBstatus(true);
    
      })

  

			}, 1000);
			// setIntervalId(id);
		} else {
			clearInterval(intervalId);
			setIntervalId("");
		}
	};

// const [timerId, setTimerId] = useState();
// // const [timer, setTimer] = useState(0);

// const onStart = () => {
//   let uid  = Math.ceil(Math.random()*1000);
//   var data = {
//     code: code,
//     input: input,
//     language :language.short,
//     id : uid,
//   }
//   axios({
//     method: "post",
//     url: "/asycompile",
//     data : data
//   }).then(o=>{console.log(o.data.output)}).catch(e=>{setBstatus(true);});

//   setTimerId(
//     setInterval(() => {
//       axios({
//         method: "get",
//         url: "/check/"+uid,
//       }).then(e=>{
      
//      setOutput(e.data.output);
//      setBstatus(true);
     
//      return;
//       }).catch(e=>{
//         setBstatus(true);
//       })
//     }, 1000)
//   );
// };
// useEffect(() => {
// if(bstatus == true)
// {
// clearInterval(timerId)

// }
//   return () => {
    
//   }
// }, [bstatus])


// const onStop = () => {
//   clearInterval(timerId);
// };

useEffect(() => {
  setId(Math.ceil(Math.random()*8000))
  if(output!="Please Wait...")
  setBstatus(true)
  // return () => clearInterval(timerId);
}, [output]);

const makecall = (uid)=>{
  var data = {
    code: code,
    input: input,
    language :language.short,
    id : uid,
  }
  axios({
    method: "post",
    url: "/asycompile",
    data : data
  }).then(o=>{console.log(o.data.output)}).catch(e=>{setBstatus(true);});

}
const onSt = (uid)=>{

  axios({
    method: "get",
    url: "/check/"+id,
  }).catch(e=>{
    onSt()
  }).then((e)=>{
  console.log(e.data.output);
setOutput(e.data.output);



  })

}
  const execute = (t)=>{
    if(bstatus==false) return ;
    if(isWait == false) {
      setOutput("Too soon! please wait for some more time before next execution")
      return ;
    }
    setIsWait(false);
    setTimeout(()=>{
setIsWait(true);
    },8000)
    setBstatus(false);
    setOutput("PleaseWait...")
    asyPromise(code,input).then((e)=>{
// console.log(e)
setOutput(e);
    }).catch((e)=>{
      setOutput("Execution TimeOut Error");
      // console.log(e)
    });
  }
    // var data = {
    //   code: code,
    //   input: input,
    // }
    // console.log(data)
    // axios({
    //   method: "post",
    //   url: "http://localhost:5000/compile",
   
    // data : data
    // }).then(o=>setOutput(o.data)).catch(e=>console.log(e));
  
    return (
    <div style={{"paddingBottom":"0px",
    
    }}><h1
    style={{


    }}>ZERO BUG</h1>
    
  {/*  */}
  {/* #1F1831 */}

<br></br>
<div className ="output">



</div >

{/* <div style ={{"resize":"both","border":"solid:"}}>hello</div> */}
<div className='e-main'>
<div className='l pane'>
<CodeEditor
      value={code}
      language={language.language}
      // placeholder="Please enter JS code."
      onChange={(e)=>setCode(e.target.value)}
      padding={15}
      // className = "e"
      style={{
        fontSize: 25,
 backgroundColor:"white",
        fontFamily: '',
        height:"80%",
        overflow:"scroll",
        opacity:".92"

      }}
    />
    <br></br>
    
    <div className={'btns-cont'}>
<button className={bstatus?"btn enabled glow-on-hover":"btn disabled .ac"} onClick = {()=>execute(3000)}>{bstatus?<>Execute</>:<>Wait</>}</button>

<button className={bstatus?"btn enabled glow-on-hover":"btn disabled .ac"} onClick = {()=>{setOutput("Please Wait...");setBstatus(false);makecall(id);onSt(id);}}>{bstatus?<>Execute(queue)</>:<>Wait</>}</button>


<div className={`dropdown`}>
        <button onClick={handleDropdownClick} className="dropdown-btn">
          {dropdownValue === "" ? "Python ᨆ" : dropdownValue+" ᨆ"}
        </button>
        <div
          className={`dropdown-items ${
            dropdownState ? "isVisible" : "isHidden"
          }`}
        >

          {
            lngArr.map((m,i)=>
               <div className="dropdown-item">
            <div
              className="dropdown__link"
              onClick={() => {handleSetDropdownValue(" "+lngArr[i].language);setLanguage(lngArr[i]);setCode(lngArr[i].initcode)}}
            >
              {lngArr[i].language}
            </div>
          </div>
            )
          }
         
         
         
         
        </div>
      </div>
      </div>

{/* <Select options={lngArr.map(m=>m.language)} onChange={(values) => this.setValues(values)} /> */}

</div>
<div className='r pane'>
<div style = {{"textAlign":"left",height:"100%"}}>
Output:<br></br>
<pre style= {
{backgroundColor:'white',opacity:".92",height:"80%","overflow-y":"scroll"}
} >{output}</pre>
</div>

<textarea style={{height:"100%" ,opacity:".92"}} placeholder='input' value = {input} onChange={(e)=>{setInput(e.target.value)}}></textarea>

</div>


</div>
<br></br>
{/* <p style={{backgroundColor:"#d6d2e1"}}>made with 💗 by <a href = "https://siddharthabajpai.netlify.app/" target="_blank">siddhartha bajpai</a> | <a href = "https://siddharthabajpai.hashnode.dev/how-i-made-my-own-python-remote-execution-platform"  target="_blank">devblog</a></p> */}
  zero-bug
    </div>
    
  )
}

export default EditorC