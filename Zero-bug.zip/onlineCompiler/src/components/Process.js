import React from 'react'
import Subprocess from './Subprocess'
import "./styles.css"
function Process() {
var obj = [{
    img1 : "https://picsum.photos/200/300",
    text: "The following example shows a menu that will float to the left of the",

},
{
    img1 : "https://picsum.photos/200/300",
    text: "The following example shows a menu that will float to the left of the",

}
,
{
    img1 : "https://picsum.photos/200/300",
    text: "The following example shows a menu that will float to the left of the",

}
]
  return (
    <div className='process'>
        <Subprocess img = {obj[0].img1} text ={obj[0].text} ></Subprocess>
        <Subprocess img = {obj[2].img1} text ={obj[2].text}></Subprocess>
        <Subprocess img = {obj[1].img1} text ={obj[1].text}></Subprocess>

    </div>
  )
}

export default Process