import React from 'react'
import "./styles.css"
export default function Subprocess({img,text}) {
  return (
    <div className = "process-card">
    <img src= {img} height ={"300px"}></img>
   <p style ={{"textAlign":"left","marginBlock":"30px"}}>{text}
   <br/> 
   <br/>
   <div className='btn-km' style = {{"padding" : "20px","textAlign":"center","border" : "2px solid black","width":"25%","cursor":"pointer"}}>
    Know More
   </div>
    </p> 
    </div>
  )
}
